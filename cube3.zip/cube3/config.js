// ============================================================
// CUBE3 PUBLIC CONFIG
// Only the project URL and the PUBLISHABLE (anon) key belong here.
// Never put the service_role / secret key in this file or anywhere
// in frontend code - it must only ever be used server-side (seed.js).
// ============================================================
window.CUBE3_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "YOUR-ANON-PUBLIC-KEY"
};
