# Cube3

**Discover creators. Connect brands. Build partnerships.**

Cube3 is a creator–brand collaboration marketplace. Creators showcase their audience and content across platforms; brands discover creators, publish campaigns, and manage applications and collaborations — all backed by a real Supabase database with Row Level Security.

This is a vanilla HTML/CSS/JS static site. There is no build step. It talks directly to Supabase from the browser using the public anon key, and every private operation is enforced by PostgreSQL Row Level Security — not by anything in the frontend.

---

## 1. What Cube3 is

- **Creators** create a profile, add their social accounts (YouTube, Instagram, TikTok, X, Facebook, LinkedIn) with follower counts, and apply to open brand campaigns.
- **Brands** create a company profile, publish campaigns with budgets/requirements/deadlines, review applications, and accept or reject creators.
- Both sides can **favorite**, **message**, and receive **notifications**.
- An **admin** role can verify creators, suspend accounts, and review campaigns.

## 2. Technologies

- HTML5 / CSS3 / vanilla JavaScript (ES6+), no framework or build tool
- [Supabase](https://supabase.com): Postgres database, Auth, Row Level Security, Storage, Realtime
- Supabase JS SDK loaded from CDN (`@supabase/supabase-js@2`)

## 3. Supabase setup

1. Create a free project at [supabase.com](https://supabase.com).
2. In **Project Settings → API**, copy:
   - `Project URL`
   - `anon` `public` key (this is the "publishable" key — safe for the browser)
3. **Do not** copy the `service_role` key into anything in this repository. It is only used by `seed.js`, run locally, never committed.

## 4. Database setup

1. Open **SQL Editor** in your Supabase project.
2. Paste the entire contents of [`schema.sql`](./schema.sql) and run it.

This creates every table (`profiles`, `creators`, `brands`, `social_accounts`, `campaigns`, `campaign_applications`, `creator_favorites`, `campaign_favorites`, `messages`, `notifications`, `profile_views`), all indexes, Row Level Security policies, notification triggers, and the three storage buckets (`avatars`, `creator-media`, `brand-logos`) with their storage policies.

Re-running `schema.sql` is safe — it uses `create table if not exists`, `on conflict do nothing`, and `create or replace function`.

### Creating the first admin account

There is no public "become an admin" flow (by design). To make a user an admin, sign up normally as any role, then in the SQL editor run:

```sql
update profiles set role = 'admin' where id = '<the user''s auth.users id>';
```

## 5. Authentication setup

Auth is Supabase Authentication with email/password. In **Authentication → Providers**, email/password is enabled by default.

- If you want email verification enforced before login, leave **"Confirm email"** ON in **Authentication → Settings**. `signup.html` will tell the user to check their inbox.
- If you're testing locally and want instant access, you can turn "Confirm email" OFF.
- Password reset uses `supabase.auth.resetPasswordForEmail` and redirects back to `login.html`. Make sure your site URL and this redirect URL are added under **Authentication → URL Configuration**.

Session persistence, refresh, and logout are all handled by the Supabase JS SDK (`auth.js`).

## 6. Storage setup

Buckets are created by `schema.sql`: `avatars`, `creator-media`, `brand-logos` — all public-read, but write access is restricted to the authenticated owner's own folder (`{user_id}/...`) via storage RLS policies. Uploads are validated client-side for file type (JPG/PNG/WEBP/GIF) and size (max 5MB) in `api.js`.

## 7. Environment variables / configuration

Because this is a plain static site (no bundler), configuration lives in **`config.js`**, which is loaded before every other script:

```js
window.CUBE3_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "YOUR-ANON-PUBLIC-KEY"
};
```

Replace the two placeholder values with your project's URL and anon key before deploying. **Only these two values ever belong in frontend code.** Never put `service_role` / secret keys / database passwords here.

If you later port this to a framework (Vite, Next.js, etc.), move these into real environment variables named `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` and inject them at build time instead.

## 8. Local development

No build tools required. From the project folder:

```bash
python3 -m http.server 5500
# or: npx serve .
```

Then open `http://localhost:5500`. Make sure you've filled in `config.js` first.

## 9. GitHub deployment (GitHub Pages)

1. Push this folder to a GitHub repository.
2. Fill in `config.js` with your real Supabase URL/anon key **before** pushing (or push a placeholder and edit it directly on GitHub — the anon key is safe to be public, since RLS enforces authorization).
3. In the repo, go to **Settings → Pages**, set **Source** to the branch/folder containing `index.html` (usually `main` / `/root`).
4. In your Supabase project, go to **Authentication → URL Configuration** and add your GitHub Pages URL (e.g. `https://yourname.github.io/cube3/`) to both **Site URL** and **Redirect URLs**, so login/reset-password redirects work.

## 10. Demo data (optional)

`seed.js` creates a handful of clearly-fictional demo creators and one demo brand + campaign, using the Supabase **service role key** (server-side only — never in the browser):

```bash
npm install
export SUPABASE_URL="https://YOUR-PROJECT-REF.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"
node seed.js
```

All seeded accounts log in with the password `Cube3Demo!123` and are clearly labeled `(Demo data)` in their descriptions. These are fictional creators/brands and do not represent real people or companies.

## 11. Security

- **RLS on every table.** Public tables (creators, brands, open campaigns) are readable by anyone; everything else (applications, messages, notifications, favorites) is restricted to the owning user via `auth.uid()` checks and `security definer` helper functions (`owns_creator`, `owns_brand`, `owns_campaign`, `current_role_is`) — see `schema.sql`.
- **No trusted client-side role.** The admin dashboard (`admin.html`) calls `Cube3Auth.requireRole('admin')`, which reads the `role` column from the `profiles` table (RLS-protected) — never from anything the browser sends. Even if a user edited local JS, every database write is still checked server-side by RLS.
- **Storage** buckets restrict uploads to a path prefixed with the uploader's own `auth.uid()`.
- **Secrets:** the frontend only ever holds `SUPABASE_URL` and the anon/publishable key. The `service_role` key is used exclusively by `seed.js`, run from a trusted machine, and is excluded from version control via `.gitignore`-style guidance (never paste it into any `.js`/`.html` file).
- **Input handling:** all user-supplied text rendered to the page goes through `escapeHtml()` to prevent XSS; all writes go through parameterized Supabase queries (no raw SQL string concatenation), which prevents SQL injection.

## 12. Production deployment checklist

- [ ] `config.js` has real `SUPABASE_URL` / anon key, no placeholders
- [ ] `schema.sql` has been run against the production Supabase project
- [ ] Auth redirect URLs configured for the production domain
- [ ] Confirmed no `service_role` key appears anywhere in the repo (`grep -R "service_role" .`)
- [ ] Ran through the manual test list below

---

## Project structure

```
cube3/
├── index.html              Home
├── creators.html            Creator discovery
├── creator.html              Creator profile (?id=)
├── brands.html               Brand directory
├── campaigns.html            Campaign discovery
├── campaign.html              Campaign detail + apply (?id=)
├── login.html
├── signup.html
├── dashboard.html            Redirects to the right dashboard by role
├── creator-dashboard.html
├── brand-dashboard.html
├── profile.html               Account settings
├── messages.html               Realtime messaging
├── notifications.html
├── admin.html
├── about.html
├── config.js                  Public Supabase URL + anon key (edit this)
├── supabase-client.js         Shared Supabase client
├── auth.js                     Auth helpers / route guards
├── api.js                      All database/storage calls
├── script.js                   Shared UI (navbar, cards, toasts, modal)
├── style.css
├── schema.sql                  Full DB schema + RLS + storage policies
├── seed.js                     Optional demo data (service role, run locally)
├── package.json
└── .gitignore
```

## Manual test checklist

1. Sign up as a creator → profile row created → redirected to creator dashboard
2. Sign up as a brand → redirected to brand dashboard
3. Creator completes profile → appears on `/creators.html`
4. Brand completes profile + creates a campaign with status "open" → appears on `/campaigns.html`
5. Search and filters on `/creators.html` and `/campaigns.html` return real, debounced results
6. Creator applies to a campaign → brand sees it under Applications
7. Brand accepts/rejects → creator sees updated status + gets a notification
8. Favoriting a creator/campaign persists and un-favorites correctly
9. Logout clears the session; visiting a dashboard while logged out redirects to `/login.html`
10. Opening another user's data directly (e.g. guessing an application ID) is blocked by RLS
11. Mobile viewport: hamburger menu, single-column grids, no horizontal scroll
12. `grep -R "service_role" .` returns nothing outside this README
