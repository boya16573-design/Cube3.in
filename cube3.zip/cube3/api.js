// ============================================================
// CUBE3 API MODULE
// All real database reads/writes go through here.
// Every function returns { data, error } and never throws.
// ============================================================

const Cube3API = (function () {

  function wrap(result) {
    if (result.error) console.error(result.error);
    return { data: result.data, error: result.error ? result.error.message : null };
  }

  // ---------------- CREATORS ----------------

  async function searchCreators({
    query = '', category = '', platform = '', country = '',
    minFollowers = 0, verifiedOnly = false, sort = 'recommended',
    page = 1, pageSize = 12
  } = {}) {
    let q = sb.from('creators').select(`
      id, handle, category, description, country, verified, engagement_rate, created_at,
      profiles!inner(full_name, avatar_url),
      social_accounts(platform, follower_count, profile_url, username)
    `, { count: 'exact' });

    if (category) q = q.eq('category', category);
    if (country) q = q.eq('country', country);
    if (verifiedOnly) q = q.eq('verified', true);
    if (query) {
      q = q.or(`handle.ilike.%${query}%,description.ilike.%${query}%,category.ilike.%${query}%`);
    }

    if (sort === 'newest') q = q.order('created_at', { ascending: false });
    else if (sort === 'engagement') q = q.order('engagement_rate', { ascending: false });
    else q = q.order('verified', { ascending: false }).order('engagement_rate', { ascending: false });

    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    q = q.range(from, to);

    const res = await q;
    let rows = res.data || [];

    // client-side refinement for platform / follower filters
    // (kept simple; for very large datasets these would move into SQL/RPC)
    if (platform) {
      rows = rows.filter(r => (r.social_accounts || []).some(s => s.platform === platform));
    }
    if (minFollowers > 0) {
      rows = rows.filter(r => (r.social_accounts || []).reduce((sum, s) => sum + (s.follower_count || 0), 0) >= minFollowers);
    }
    if (sort === 'followers') {
      rows.sort((a, b) => {
        const fa = (a.social_accounts || []).reduce((s, x) => s + x.follower_count, 0);
        const fb = (b.social_accounts || []).reduce((s, x) => s + x.follower_count, 0);
        return fb - fa;
      });
    }

    return { data: rows, count: res.count, error: res.error ? res.error.message : null };
  }

  async function getCreatorById(id) {
    const res = await sb.from('creators').select(`
      *, profiles!inner(full_name, avatar_url, bio, website),
      social_accounts(*)
    `).eq('id', id).single();
    return wrap(res);
  }

  async function getCreatorByProfileId(profileId) {
    const res = await sb.from('creators').select('*').eq('profile_id', profileId).maybeSingle();
    return wrap(res);
  }

  async function upsertMyCreatorProfile(profileId, fields) {
    const res = await sb.from('creators').upsert({ profile_id: profileId, ...fields }, { onConflict: 'profile_id' }).select().single();
    return wrap(res);
  }

  async function logProfileView(creatorId, viewerId) {
    return wrap(await sb.from('profile_views').insert({ creator_id: creatorId, viewer_id: viewerId || null }));
  }

  async function upsertSocialAccount(creatorId, platform, fields) {
    const res = await sb.from('social_accounts').upsert({
      creator_id: creatorId, platform, ...fields, updated_at: new Date().toISOString()
    }, { onConflict: 'creator_id,platform' }).select().single();
    return wrap(res);
  }

  async function deleteSocialAccount(id) {
    return wrap(await sb.from('social_accounts').delete().eq('id', id));
  }

  async function getMySocialAccounts(creatorId) {
    return wrap(await sb.from('social_accounts').select('*').eq('creator_id', creatorId));
  }

  // ---------------- BRANDS ----------------

  async function getBrandByProfileId(profileId) {
    const res = await sb.from('brands').select('*').eq('profile_id', profileId).maybeSingle();
    return wrap(res);
  }

  async function upsertMyBrandProfile(profileId, fields) {
    const res = await sb.from('brands').upsert({ profile_id: profileId, ...fields }, { onConflict: 'profile_id' }).select().single();
    return wrap(res);
  }

  async function listBrands({ page = 1, pageSize = 12 } = {}) {
    const from = (page - 1) * pageSize, to = from + pageSize - 1;
    const res = await sb.from('brands').select('*, profiles!inner(full_name)').range(from, to).order('created_at', { ascending: false });
    return wrap(res);
  }

  // ---------------- CAMPAIGNS ----------------

  async function searchCampaigns({ query = '', category = '', platform = '', status = 'open', page = 1, pageSize = 12 } = {}) {
    let q = sb.from('campaigns').select(`
      *, brands!inner(company_name, logo_url),
      campaign_applications(count)
    `, { count: 'exact' });
    if (status) q = q.eq('status', status);
    if (category) q = q.eq('category', category);
    if (query) q = q.or(`title.ilike.%${query}%,description.ilike.%${query}%`);
    if (platform) q = q.contains('platforms', [platform]);
    const from = (page - 1) * pageSize, to = from + pageSize - 1;
    q = q.order('created_at', { ascending: false }).range(from, to);
    const res = await q;
    return { data: res.data, count: res.count, error: res.error ? res.error.message : null };
  }

  async function getCampaignById(id) {
    const res = await sb.from('campaigns').select(`
      *, brands!inner(company_name, logo_url, website, profile_id)
    `).eq('id', id).single();
    return wrap(res);
  }

  async function getMyCampaigns(brandId) {
    return wrap(await sb.from('campaigns').select('*, campaign_applications(count)').eq('brand_id', brandId).order('created_at', { ascending: false }));
  }

  async function createCampaign(fields) {
    return wrap(await sb.from('campaigns').insert(fields).select().single());
  }

  async function updateCampaign(id, fields) {
    return wrap(await sb.from('campaigns').update(fields).eq('id', id).select().single());
  }

  async function deleteCampaign(id) {
    return wrap(await sb.from('campaigns').delete().eq('id', id));
  }

  // ---------------- APPLICATIONS ----------------

  async function applyToCampaign({ campaignId, creatorId, pitch, proposedFee, portfolioUrl, message }) {
    const res = await sb.from('campaign_applications').insert({
      campaign_id: campaignId, creator_id: creatorId, pitch,
      proposed_fee: proposedFee || null, portfolio_url: portfolioUrl || null, message: message || null
    }).select().single();
    return wrap(res);
  }

  async function getMyApplications(creatorId) {
    return wrap(await sb.from('campaign_applications').select(`
      *, campaigns!inner(title, status, brand_id, brands!inner(company_name, logo_url))
    `).eq('creator_id', creatorId).order('created_at', { ascending: false }));
  }

  async function getApplicationsForCampaign(campaignId) {
    return wrap(await sb.from('campaign_applications').select(`
      *, creators!inner(id, handle, category, verified, profiles!inner(full_name, avatar_url))
    `).eq('campaign_id', campaignId).order('created_at', { ascending: false }));
  }

  async function updateApplicationStatus(id, status) {
    return wrap(await sb.from('campaign_applications').update({ status, updated_at: new Date().toISOString() }).eq('id', id).select().single());
  }

  async function withdrawApplication(id) {
    return wrap(await sb.from('campaign_applications').update({ status: 'withdrawn' }).eq('id', id).select().single());
  }

  // ---------------- FAVORITES ----------------

  async function favoriteCreator(profileId, creatorId) {
    return wrap(await sb.from('creator_favorites').insert({ profile_id: profileId, creator_id: creatorId }));
  }
  async function unfavoriteCreator(profileId, creatorId) {
    return wrap(await sb.from('creator_favorites').delete().eq('profile_id', profileId).eq('creator_id', creatorId));
  }
  async function getMyFavoriteCreators(profileId) {
    return wrap(await sb.from('creator_favorites').select('creator_id, creators!inner(*, profiles!inner(full_name, avatar_url))').eq('profile_id', profileId));
  }
  async function isCreatorFavorited(profileId, creatorId) {
    const res = await sb.from('creator_favorites').select('id').eq('profile_id', profileId).eq('creator_id', creatorId).maybeSingle();
    return !!res.data;
  }

  async function favoriteCampaign(profileId, campaignId) {
    return wrap(await sb.from('campaign_favorites').insert({ profile_id: profileId, campaign_id: campaignId }));
  }
  async function unfavoriteCampaign(profileId, campaignId) {
    return wrap(await sb.from('campaign_favorites').delete().eq('profile_id', profileId).eq('campaign_id', campaignId));
  }
  async function getMyFavoriteCampaigns(profileId) {
    return wrap(await sb.from('campaign_favorites').select('campaign_id, campaigns!inner(*, brands!inner(company_name, logo_url))').eq('profile_id', profileId));
  }

  // ---------------- MESSAGES ----------------

  async function getConversations(profileId) {
    const res = await sb.from('messages')
      .select('*')
      .or(`sender_id.eq.${profileId},receiver_id.eq.${profileId}`)
      .order('created_at', { ascending: false });
    if (res.error) return wrap(res);
    // collapse into unique conversation partners
    const map = new Map();
    for (const m of res.data) {
      const partnerId = m.sender_id === profileId ? m.receiver_id : m.sender_id;
      if (!map.has(partnerId)) map.set(partnerId, { partnerId, lastMessage: m, unread: 0 });
      if (m.receiver_id === profileId && !m.read) map.get(partnerId).unread++;
    }
    return { data: Array.from(map.values()), error: null };
  }

  async function getThread(profileId, partnerId) {
    return wrap(await sb.from('messages')
      .select('*')
      .or(`and(sender_id.eq.${profileId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${profileId})`)
      .order('created_at', { ascending: true }));
  }

  async function sendMessage({ senderId, receiverId, message, campaignId = null }) {
    return wrap(await sb.from('messages').insert({ sender_id: senderId, receiver_id: receiverId, message, campaign_id: campaignId }).select().single());
  }

  async function markThreadRead(profileId, partnerId) {
    return wrap(await sb.from('messages').update({ read: true }).eq('receiver_id', profileId).eq('sender_id', partnerId).eq('read', false));
  }

  function subscribeToMessages(profileId, callback) {
    return sb.channel('messages-' + profileId)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${profileId}` }, callback)
      .subscribe();
  }

  // ---------------- NOTIFICATIONS ----------------

  async function getNotifications(userId) {
    return wrap(await sb.from('notifications').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(50));
  }
  async function getUnreadNotificationCount(userId) {
    const res = await sb.from('notifications').select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('read', false);
    return res.count || 0;
  }
  async function markNotificationRead(id) {
    return wrap(await sb.from('notifications').update({ read: true }).eq('id', id));
  }
  async function markAllNotificationsRead(userId) {
    return wrap(await sb.from('notifications').update({ read: true }).eq('user_id', userId).eq('read', false));
  }

  // ---------------- STORAGE ----------------

  async function uploadFile(bucket, userId, file) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      return { error: 'Only JPG, PNG, WEBP or GIF images are allowed.' };
    }
    if (file.size > 5 * 1024 * 1024) {
      return { error: 'File must be smaller than 5MB.' };
    }
    const ext = file.name.split('.').pop();
    const path = `${userId}/${Date.now()}.${ext}`;
    const { error: uploadErr } = await sb.storage.from(bucket).upload(path, file, { upsert: true });
    if (uploadErr) return { error: uploadErr.message };
    const { data } = sb.storage.from(bucket).getPublicUrl(path);
    return { data: data.publicUrl };
  }

  // ---------------- ADMIN ----------------

  async function adminGetStats() {
    const [users, creators, brands, campaigns, applications] = await Promise.all([
      sb.from('profiles').select('id', { count: 'exact', head: true }),
      sb.from('creators').select('id', { count: 'exact', head: true }),
      sb.from('brands').select('id', { count: 'exact', head: true }),
      sb.from('campaigns').select('id', { count: 'exact', head: true }),
      sb.from('campaign_applications').select('id', { count: 'exact', head: true })
    ]);
    return {
      users: users.count || 0, creators: creators.count || 0, brands: brands.count || 0,
      campaigns: campaigns.count || 0, applications: applications.count || 0
    };
  }
  async function adminListUsers() {
    return wrap(await sb.from('profiles').select('*').order('created_at', { ascending: false }).limit(100));
  }
  async function adminVerifyCreator(creatorId, verified) {
    return wrap(await sb.from('creators').update({ verified }).eq('id', creatorId));
  }
  async function adminSuspendUser(profileId, suspended) {
    return wrap(await sb.from('profiles').update({ is_suspended: suspended }).eq('id', profileId));
  }
  async function adminListCampaigns() {
    return wrap(await sb.from('campaigns').select('*, brands!inner(company_name)').order('created_at', { ascending: false }).limit(100));
  }

  return {
    searchCreators, getCreatorById, getCreatorByProfileId, upsertMyCreatorProfile, logProfileView,
    upsertSocialAccount, deleteSocialAccount, getMySocialAccounts,
    getBrandByProfileId, upsertMyBrandProfile, listBrands,
    searchCampaigns, getCampaignById, getMyCampaigns, createCampaign, updateCampaign, deleteCampaign,
    applyToCampaign, getMyApplications, getApplicationsForCampaign, updateApplicationStatus, withdrawApplication,
    favoriteCreator, unfavoriteCreator, getMyFavoriteCreators, isCreatorFavorited,
    favoriteCampaign, unfavoriteCampaign, getMyFavoriteCampaigns,
    getConversations, getThread, sendMessage, markThreadRead, subscribeToMessages,
    getNotifications, getUnreadNotificationCount, markNotificationRead, markAllNotificationsRead,
    uploadFile,
    adminGetStats, adminListUsers, adminVerifyCreator, adminSuspendUser, adminListCampaigns
  };
})();
