// ============================================================
// CUBE3 SUPABASE CLIENT
// Loads the Supabase JS SDK from CDN (see script tag in HTML)
// and exposes a single shared client instance as window.sb
// ============================================================
(function () {
  const cfg = window.CUBE3_CONFIG;
  if (!cfg || cfg.SUPABASE_URL.includes('YOUR-PROJECT-REF')) {
    console.warn(
      'Cube3: config.js still has placeholder Supabase credentials. ' +
      'Update SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY in config.js.'
    );
  }
  window.sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  });
})();
