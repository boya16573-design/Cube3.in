// ============================================================
// CUBE3 SHARED UI UTILITIES
// ============================================================

function debounce(fn, delay = 350) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

function formatFollowers(n) {
  n = n || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(n);
}

function formatMoney(n, currency = 'USD') {
  if (n === null || n === undefined) return '—';
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
  } catch { return `$${n}`; }
}

function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  if (diff < 2592000) return Math.floor(diff / 86400) + 'd ago';
  return new Date(dateStr).toLocaleDateString();
}

function toast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3800);
}

function friendlyError(msg) {
  if (!msg) return 'Something went wrong. Please try again.';
  const lower = msg.toLowerCase();
  if (lower.includes('duplicate')) return 'That already exists.';
  if (lower.includes('permission') || lower.includes('policy')) return 'You do not have permission to do that.';
  if (lower.includes('network')) return 'Network error. Please check your connection.';
  return 'Something went wrong. Please try again.';
}

function openModal(html) {
  closeModal();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'active-modal';
  overlay.innerHTML = `<div class="modal-card">${html}</div>`;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add('show'));
}
function closeModal() {
  const existing = document.getElementById('active-modal');
  if (existing) existing.remove();
}

function loadingSpinnerHTML(label = 'Loading...') {
  return `<div class="empty-state"><div class="spinner"></div><p>${escapeHtml(label)}</p></div>`;
}
function emptyStateHTML(title, subtitle = '', actionHtml = '') {
  return `<div class="empty-state">
    <div class="empty-icon">◇</div>
    <h3>${escapeHtml(title)}</h3>
    ${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ''}
    ${actionHtml}
  </div>`;
}
function retryStateHTML(message, retryFnName) {
  return `<div class="empty-state">
    <div class="empty-icon">!</div>
    <p>${escapeHtml(message)}</p>
    <button class="btn btn-secondary" onclick="${retryFnName}()">Try again</button>
  </div>`;
}

// ---------------- NAVBAR ----------------

async function renderNavbar() {
  const mount = document.getElementById('navbar');
  if (!mount) return;

  const profile = await Cube3Auth.getCurrentProfile();
  const dashHref = profile ? (profile.role === 'creator' ? 'creator-dashboard.html' : profile.role === 'brand' ? 'brand-dashboard.html' : 'admin.html') : 'login.html';

  mount.innerHTML = `
    <nav class="navbar">
      <div class="nav-inner">
        <a href="index.html" class="logo">Cube<span class="logo-3">3</span></a>
        <button class="nav-toggle" id="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
          <span></span><span></span><span></span>
        </button>
        <div class="nav-links" id="nav-links">
          <a href="creators.html">Creators</a>
          <a href="brands.html">Brands</a>
          <a href="campaigns.html">Campaigns</a>
          <a href="about.html">About</a>
        </div>
        <div class="nav-actions" id="nav-actions">
          ${profile ? `
            <a href="notifications.html" class="icon-btn" id="notif-btn" title="Notifications">
              🔔<span class="badge-dot" id="notif-badge" hidden></span>
            </a>
            <a href="${dashHref}" class="btn btn-ghost">Dashboard</a>
            <a href="profile.html" class="btn btn-ghost">Profile</a>
            <button class="btn btn-primary" id="logout-btn">Logout</button>
          ` : `
            <a href="login.html" class="btn btn-ghost">Login</a>
            <a href="signup.html" class="btn btn-primary">Join Cube3</a>
          `}
          <button class="icon-btn" id="theme-toggle" title="Toggle theme">◐</button>
        </div>
      </div>
    </nav>`;

  document.getElementById('nav-toggle').addEventListener('click', () => {
    const links = document.getElementById('nav-links');
    const actions = document.getElementById('nav-actions');
    const expanded = links.classList.toggle('open');
    actions.classList.toggle('open');
    document.getElementById('nav-toggle').setAttribute('aria-expanded', String(expanded));
  });

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => Cube3Auth.signOut());

  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

  if (profile) {
    const count = await Cube3API.getUnreadNotificationCount(profile.id);
    const badge = document.getElementById('notif-badge');
    if (badge && count > 0) badge.hidden = false;
  }
}

function renderFooter() {
  const mount = document.getElementById('footer');
  if (!mount) return;
  mount.innerHTML = `
    <footer class="footer">
      <div class="footer-inner">
        <div>
          <a href="index.html" class="logo">Cube<span class="logo-3">3</span></a>
          <p class="footer-tagline">Discover creators. Connect brands. Build partnerships.</p>
        </div>
        <div class="footer-cols">
          <div>
            <h4>Platform</h4>
            <a href="creators.html">Creators</a>
            <a href="brands.html">Brands</a>
            <a href="campaigns.html">Campaigns</a>
          </div>
          <div>
            <h4>Company</h4>
            <a href="about.html">About</a>
            <a href="signup.html">Join Cube3</a>
            <a href="login.html">Login</a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">© ${new Date().getFullYear()} Cube3. This is demo software; sample data is fictional.</div>
    </footer>`;
}

// ---------------- THEME ----------------

function applyStoredTheme() {
  const theme = localStorage.getItem('cube3-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', theme);
}
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('cube3-theme', next);
}
applyStoredTheme();

// ---------------- CREATOR CARD ----------------

function creatorCardHTML(c) {
  const followers = (c.social_accounts || []).reduce((s, x) => s + (x.follower_count || 0), 0);
  const yt = (c.social_accounts || []).find(s => s.platform === 'youtube');
  const ig = (c.social_accounts || []).find(s => s.platform === 'instagram');
  const x = (c.social_accounts || []).find(s => s.platform === 'x');
  const name = c.profiles?.full_name || 'Creator';
  const avatar = c.profiles?.avatar_url || '';
  return `
  <div class="creator-card">
    <a href="creator.html?id=${c.id}" class="creator-card-top">
      <div class="avatar">${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(name)}" loading="lazy">` : escapeHtml(name.charAt(0))}</div>
      <div>
        <div class="creator-name">${escapeHtml(name)} ${c.verified ? '<span class="verify-badge" title="Verified">✓</span>' : ''}</div>
        <div class="creator-handle">@${escapeHtml(c.handle)}</div>
      </div>
    </a>
    <div class="creator-tags">
      <span class="tag">${escapeHtml(c.category)}</span>
      ${c.country ? `<span class="tag tag-muted">${escapeHtml(c.country)}</span>` : ''}
    </div>
    <p class="creator-desc">${escapeHtml((c.description || '').slice(0, 110))}${(c.description || '').length > 110 ? '…' : ''}</p>
    <div class="creator-stats">
      ${yt ? `<div><strong>${formatFollowers(yt.follower_count)}</strong><span>YouTube</span></div>` : ''}
      ${ig ? `<div><strong>${formatFollowers(ig.follower_count)}</strong><span>Instagram</span></div>` : ''}
      ${x ? `<div><strong>${formatFollowers(x.follower_count)}</strong><span>X</span></div>` : ''}
      <div><strong>${(c.engagement_rate || 0).toFixed(1)}%</strong><span>Engagement</span></div>
    </div>
    <div class="creator-card-actions">
      <button class="btn btn-ghost btn-sm favorite-btn" data-creator-id="${c.id}">♡ Favorite</button>
      <a href="creator.html?id=${c.id}" class="btn btn-primary btn-sm">View Profile</a>
    </div>
  </div>`;
}

function campaignCardHTML(c) {
  const appCount = c.campaign_applications?.[0]?.count ?? 0;
  return `
  <div class="campaign-card">
    <div class="campaign-card-top">
      <div class="avatar avatar-sq">${c.brands?.logo_url ? `<img src="${escapeHtml(c.brands.logo_url)}" alt="">` : escapeHtml((c.brands?.company_name || 'B').charAt(0))}</div>
      <div>
        <div class="campaign-brand">${escapeHtml(c.brands?.company_name || 'Brand')}</div>
        <div class="tag">${escapeHtml(c.category)}</div>
      </div>
      <span class="status-pill status-${c.status}">${c.status}</span>
    </div>
    <h3 class="campaign-title"><a href="campaign.html?id=${c.id}">${escapeHtml(c.title)}</a></h3>
    <p class="creator-desc">${escapeHtml((c.description || '').slice(0, 120))}${(c.description || '').length > 120 ? '…' : ''}</p>
    <div class="campaign-meta">
      <span>${formatMoney(c.budget_min, c.currency)} – ${formatMoney(c.budget_max, c.currency)}</span>
      <span>${appCount} applicant${appCount === 1 ? '' : 's'}</span>
    </div>
    <a href="campaign.html?id=${c.id}" class="btn btn-primary btn-sm btn-block">View Campaign</a>
  </div>`;
}

async function initFavoriteButtons(container) {
  const profile = await Cube3Auth.getCurrentProfile();
  container.querySelectorAll('.favorite-btn').forEach(async (btn) => {
    const creatorId = btn.dataset.creatorId;
    if (profile) {
      const fav = await Cube3API.isCreatorFavorited(profile.id, creatorId);
      if (fav) { btn.textContent = '♥ Favorited'; btn.classList.add('is-favorited'); }
    }
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      if (!profile) { window.location.href = 'login.html'; return; }
      const isFav = btn.classList.contains('is-favorited');
      if (isFav) {
        await Cube3API.unfavoriteCreator(profile.id, creatorId);
        btn.textContent = '♡ Favorite'; btn.classList.remove('is-favorited');
        toast('Removed from favorites');
      } else {
        const { error } = await Cube3API.favoriteCreator(profile.id, creatorId);
        if (!error) {
          btn.textContent = '♥ Favorited'; btn.classList.add('is-favorited');
          toast('Added to favorites', 'success');
        }
      }
    });
  });
}

// pagination widget
function paginationHTML(page, totalPages) {
  if (totalPages <= 1) return '';
  let html = '<div class="pagination">';
  html += `<button class="btn btn-ghost btn-sm" ${page <= 1 ? 'disabled' : ''} data-page="${page - 1}">← Prev</button>`;
  html += `<span class="page-indicator">Page ${page} of ${totalPages}</span>`;
  html += `<button class="btn btn-ghost btn-sm" ${page >= totalPages ? 'disabled' : ''} data-page="${page + 1}">Next →</button>`;
  html += '</div>';
  return html;
}
