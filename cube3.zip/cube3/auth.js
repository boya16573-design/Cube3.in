// ============================================================
// CUBE3 AUTH MODULE
// ============================================================

const Cube3Auth = (function () {

  async function getSession() {
    const { data, error } = await sb.auth.getSession();
    if (error) { console.error(error); return null; }
    return data.session;
  }

  async function getCurrentProfile() {
    const session = await getSession();
    if (!session) return null;
    const { data, error } = await sb
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();
    if (error) { console.error(error); return null; }
    return data;
  }

  async function signUp({ fullName, email, password, accountType }) {
    if (!fullName || !email || !password || !accountType) {
      return { error: 'Please fill in all fields.' };
    }
    if (!['creator', 'brand'].includes(accountType)) {
      return { error: 'Invalid account type.' };
    }
    const { data, error } = await sb.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName, role: accountType } }
    });
    if (error) return { error: error.message };

    // Create the profile row. If email confirmation is required,
    // there may be no active session yet - insert still works because
    // signUp returns a user id and RLS check is auth.uid() = id which
    // matches once the client has the session (email-confirm-off) or
    // after confirmation (email-confirm-on, first login triggers this).
    if (data.user) {
      const { error: profileErr } = await sb.from('profiles').insert({
        id: data.user.id,
        role: accountType,
        full_name: fullName
      });
      // Ignore duplicate errors (row may already exist from a retry)
      if (profileErr && !profileErr.message.includes('duplicate')) {
        console.warn('Profile creation deferred:', profileErr.message);
      }
    }
    return { data, needsEmailConfirmation: !data.session };
  }

  async function ensureProfileExists() {
    // Called after login in case email-confirmation delayed profile insert
    const session = await getSession();
    if (!session) return;
    const { data: existing } = await sb.from('profiles').select('id').eq('id', session.user.id).maybeSingle();
    if (!existing) {
      const meta = session.user.user_metadata || {};
      await sb.from('profiles').insert({
        id: session.user.id,
        role: meta.role || 'creator',
        full_name: meta.full_name || session.user.email
      });
    }
  }

  async function signIn({ email, password }) {
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    await ensureProfileExists();
    return { data };
  }

  async function signOut() {
    await sb.auth.signOut();
    window.location.href = 'index.html';
  }

  async function resetPassword(email) {
    const { error } = await sb.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + '/login.html'
    });
    if (error) return { error: error.message };
    return { success: true };
  }

  async function updatePassword(newPassword) {
    const { error } = await sb.auth.updateUser({ password: newPassword });
    if (error) return { error: error.message };
    return { success: true };
  }

  // Redirects to login.html if not authenticated. Returns the profile.
  async function requireAuth() {
    const profile = await getCurrentProfile();
    if (!profile) {
      window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
      return null;
    }
    if (profile.is_suspended) {
      alert('Your account has been suspended. Contact support.');
      await signOut();
      return null;
    }
    return profile;
  }

  async function requireRole(role) {
    const profile = await requireAuth();
    if (!profile) return null;
    if (profile.role !== role) {
      window.location.href = 'dashboard.html';
      return null;
    }
    return profile;
  }

  return {
    getSession, getCurrentProfile, signUp, signIn, signOut,
    resetPassword, updatePassword, requireAuth, requireRole, ensureProfileExists
  };
})();
