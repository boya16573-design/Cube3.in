-- ============================================================
-- CUBE3 DATABASE SCHEMA
-- Run this entire file in the Supabase SQL Editor
-- (Project -> SQL Editor -> New Query -> paste -> Run)
-- ============================================================

create extension if not exists "uuid-ossp";

-- ============================================================
-- 1. PROFILES  (one row per auth.users row)
-- ============================================================
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('creator','brand','admin')),
  full_name text not null,
  avatar_url text,
  bio text,
  website text,
  is_suspended boolean not null default false,
  created_at timestamptz not null default now()
);

-- ============================================================
-- 2. CREATORS
-- ============================================================
create table if not exists creators (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null unique references profiles(id) on delete cascade,
  handle text not null unique,
  category text not null,
  description text,
  country text,
  verified boolean not null default false,
  engagement_rate numeric(5,2) default 0,
  created_at timestamptz not null default now()
);
create index if not exists idx_creators_category on creators(category);
create index if not exists idx_creators_handle on creators(handle);
create index if not exists idx_creators_country on creators(country);

-- ============================================================
-- 3. BRANDS
-- ============================================================
create table if not exists brands (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null unique references profiles(id) on delete cascade,
  company_name text not null,
  logo_url text,
  website text,
  description text,
  industry text,
  country text,
  created_at timestamptz not null default now()
);
create index if not exists idx_brands_industry on brands(industry);

-- ============================================================
-- 4. SOCIAL ACCOUNTS
-- ============================================================
create table if not exists social_accounts (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references creators(id) on delete cascade,
  platform text not null check (platform in ('youtube','instagram','tiktok','x','facebook','linkedin')),
  profile_url text not null,
  username text,
  follower_count bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (creator_id, platform)
);
create index if not exists idx_social_creator on social_accounts(creator_id);

-- ============================================================
-- 5. CAMPAIGNS
-- ============================================================
create table if not exists campaigns (
  id uuid primary key default uuid_generate_v4(),
  brand_id uuid not null references brands(id) on delete cascade,
  title text not null,
  description text not null,
  category text not null,
  budget_min numeric(12,2),
  budget_max numeric(12,2),
  currency text not null default 'USD',
  platforms text[] not null default '{}',
  requirements text,
  required_audience_size integer,
  preferred_country text,
  deliverables text,
  deadline date,
  status text not null default 'draft' check (status in ('draft','open','paused','closed')),
  created_at timestamptz not null default now()
);
create index if not exists idx_campaigns_status on campaigns(status);
create index if not exists idx_campaigns_brand on campaigns(brand_id);
create index if not exists idx_campaigns_category on campaigns(category);

-- ============================================================
-- 6. CAMPAIGN APPLICATIONS
-- ============================================================
create table if not exists campaign_applications (
  id uuid primary key default uuid_generate_v4(),
  campaign_id uuid not null references campaigns(id) on delete cascade,
  creator_id uuid not null references creators(id) on delete cascade,
  pitch text not null,
  proposed_fee numeric(12,2),
  portfolio_url text,
  message text,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (campaign_id, creator_id)
);
create index if not exists idx_applications_campaign on campaign_applications(campaign_id);
create index if not exists idx_applications_creator on campaign_applications(creator_id);

-- ============================================================
-- 7. FAVORITES
-- ============================================================
create table if not exists creator_favorites (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null references profiles(id) on delete cascade,
  creator_id uuid not null references creators(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (profile_id, creator_id)
);

create table if not exists campaign_favorites (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null references profiles(id) on delete cascade,
  campaign_id uuid not null references campaigns(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (profile_id, campaign_id)
);

-- ============================================================
-- 8. MESSAGES
-- ============================================================
create table if not exists messages (
  id uuid primary key default uuid_generate_v4(),
  sender_id uuid not null references profiles(id) on delete cascade,
  receiver_id uuid not null references profiles(id) on delete cascade,
  campaign_id uuid references campaigns(id) on delete set null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_messages_sender on messages(sender_id);
create index if not exists idx_messages_receiver on messages(receiver_id);

-- ============================================================
-- 9. NOTIFICATIONS
-- ============================================================
create table if not exists notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  title text not null,
  message text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_notifications_user on notifications(user_id);

-- ============================================================
-- 10. PROFILE VIEWS (for creator dashboard "profile views" stat)
-- ============================================================
create table if not exists profile_views (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references creators(id) on delete cascade,
  viewer_id uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_profile_views_creator on profile_views(creator_id);

-- ============================================================
-- HELPER FUNCTION: current user's role (avoids recursive RLS lookups)
-- ============================================================
create or replace function public.current_role_is(target_role text)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role = target_role
  );
$$;

create or replace function public.owns_creator(target_creator_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from creators c
    where c.id = target_creator_id and c.profile_id = auth.uid()
  );
$$;

create or replace function public.owns_brand(target_brand_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from brands b
    where b.id = target_brand_id and b.profile_id = auth.uid()
  );
$$;

create or replace function public.owns_campaign(target_campaign_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from campaigns c
    join brands b on b.id = c.brand_id
    where c.id = target_campaign_id and b.profile_id = auth.uid()
  );
$$;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table profiles enable row level security;
alter table creators enable row level security;
alter table brands enable row level security;
alter table social_accounts enable row level security;
alter table campaigns enable row level security;
alter table campaign_applications enable row level security;
alter table creator_favorites enable row level security;
alter table campaign_favorites enable row level security;
alter table messages enable row level security;
alter table notifications enable row level security;
alter table profile_views enable row level security;

-- ---------- PROFILES ----------
create policy "profiles_select_public" on profiles
  for select using (true);

create policy "profiles_insert_self" on profiles
  for insert with check (auth.uid() = id);

create policy "profiles_update_self" on profiles
  for update using (auth.uid() = id and role <> 'admin')
  with check (auth.uid() = id);

-- ---------- CREATORS ----------
create policy "creators_select_public" on creators
  for select using (true);

create policy "creators_insert_self" on creators
  for insert with check (auth.uid() = profile_id);

create policy "creators_update_self" on creators
  for update using (auth.uid() = profile_id)
  with check (auth.uid() = profile_id);

create policy "creators_update_admin" on creators
  for update using (public.current_role_is('admin'));

create policy "creators_delete_self_or_admin" on creators
  for delete using (auth.uid() = profile_id or public.current_role_is('admin'));

-- ---------- BRANDS ----------
create policy "brands_select_public" on brands
  for select using (true);

create policy "brands_insert_self" on brands
  for insert with check (auth.uid() = profile_id);

create policy "brands_update_self" on brands
  for update using (auth.uid() = profile_id)
  with check (auth.uid() = profile_id);

create policy "brands_delete_self_or_admin" on brands
  for delete using (auth.uid() = profile_id or public.current_role_is('admin'));

-- ---------- SOCIAL ACCOUNTS ----------
create policy "social_select_public" on social_accounts
  for select using (true);

create policy "social_insert_owner" on social_accounts
  for insert with check (public.owns_creator(creator_id));

create policy "social_update_owner" on social_accounts
  for update using (public.owns_creator(creator_id))
  with check (public.owns_creator(creator_id));

create policy "social_delete_owner" on social_accounts
  for delete using (public.owns_creator(creator_id));

-- ---------- CAMPAIGNS ----------
create policy "campaigns_select_open_public" on campaigns
  for select using (status = 'open' or public.owns_campaign(id));

create policy "campaigns_insert_owner" on campaigns
  for insert with check (public.owns_brand(brand_id));

create policy "campaigns_update_owner" on campaigns
  for update using (public.owns_brand(brand_id))
  with check (public.owns_brand(brand_id));

create policy "campaigns_delete_owner" on campaigns
  for delete using (public.owns_brand(brand_id));

-- ---------- CAMPAIGN APPLICATIONS ----------
create policy "applications_select_owner" on campaign_applications
  for select using (
    public.owns_creator(creator_id) or public.owns_campaign(campaign_id)
  );

create policy "applications_insert_creator" on campaign_applications
  for insert with check (public.owns_creator(creator_id));

create policy "applications_update_creator_or_brand" on campaign_applications
  for update using (
    public.owns_creator(creator_id) or public.owns_campaign(campaign_id)
  ) with check (
    public.owns_creator(creator_id) or public.owns_campaign(campaign_id)
  );

create policy "applications_delete_creator" on campaign_applications
  for delete using (public.owns_creator(creator_id));

-- ---------- CREATOR FAVORITES ----------
create policy "creator_favorites_select_self" on creator_favorites
  for select using (auth.uid() = profile_id);

create policy "creator_favorites_insert_self" on creator_favorites
  for insert with check (auth.uid() = profile_id);

create policy "creator_favorites_delete_self" on creator_favorites
  for delete using (auth.uid() = profile_id);

-- ---------- CAMPAIGN FAVORITES ----------
create policy "campaign_favorites_select_self" on campaign_favorites
  for select using (auth.uid() = profile_id);

create policy "campaign_favorites_insert_self" on campaign_favorites
  for insert with check (auth.uid() = profile_id);

create policy "campaign_favorites_delete_self" on campaign_favorites
  for delete using (auth.uid() = profile_id);

-- ---------- MESSAGES ----------
create policy "messages_select_participant" on messages
  for select using (auth.uid() = sender_id or auth.uid() = receiver_id);

create policy "messages_insert_sender" on messages
  for insert with check (auth.uid() = sender_id);

create policy "messages_update_receiver" on messages
  for update using (auth.uid() = receiver_id)
  with check (auth.uid() = receiver_id);

-- ---------- NOTIFICATIONS ----------
create policy "notifications_select_self" on notifications
  for select using (auth.uid() = user_id);

create policy "notifications_update_self" on notifications
  for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "notifications_insert_system" on notifications
  for insert with check (true);

-- ---------- PROFILE VIEWS ----------
create policy "profile_views_select_owner" on profile_views
  for select using (public.owns_creator(creator_id));

create policy "profile_views_insert_anyone" on profile_views
  for insert with check (true);

-- ============================================================
-- TRIGGERS: notifications on application status change / new application
-- ============================================================
create or replace function public.notify_new_application()
returns trigger language plpgsql security definer as $$
declare
  v_brand_profile uuid;
  v_campaign_title text;
begin
  select b.profile_id, c.title into v_brand_profile, v_campaign_title
  from campaigns c join brands b on b.id = c.brand_id
  where c.id = new.campaign_id;

  insert into notifications (user_id, type, title, message)
  values (v_brand_profile, 'new_application', 'New application received',
          'A creator applied to your campaign "' || v_campaign_title || '"');
  return new;
end;
$$;

drop trigger if exists trg_notify_new_application on campaign_applications;
create trigger trg_notify_new_application
  after insert on campaign_applications
  for each row execute function public.notify_new_application();

create or replace function public.notify_application_status_change()
returns trigger language plpgsql security definer as $$
declare
  v_creator_profile uuid;
  v_campaign_title text;
begin
  if new.status <> old.status and new.status in ('accepted','rejected') then
    select cr.profile_id, c.title into v_creator_profile, v_campaign_title
    from creators cr, campaigns c
    where cr.id = new.creator_id and c.id = new.campaign_id;

    insert into notifications (user_id, type, title, message)
    values (v_creator_profile,
            'application_' || new.status,
            'Application ' || new.status,
            'Your application to "' || v_campaign_title || '" was ' || new.status);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_notify_application_status on campaign_applications;
create trigger trg_notify_application_status
  after update on campaign_applications
  for each row execute function public.notify_application_status_change();

create or replace function public.notify_new_message()
returns trigger language plpgsql security definer as $$
begin
  insert into notifications (user_id, type, title, message)
  values (new.receiver_id, 'new_message', 'New message', left(new.message, 80));
  return new;
end;
$$;

drop trigger if exists trg_notify_new_message on messages;
create trigger trg_notify_new_message
  after insert on messages
  for each row execute function public.notify_new_message();

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('creator-media', 'creator-media', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('brand-logos', 'brand-logos', true)
on conflict (id) do nothing;

-- Storage RLS: users may only write into a folder named after their own uid
create policy "avatars_public_read" on storage.objects
  for select using (bucket_id = 'avatars');
create policy "avatars_owner_write" on storage.objects
  for insert with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_owner_update" on storage.objects
  for update using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_owner_delete" on storage.objects
  for delete using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "creator_media_public_read" on storage.objects
  for select using (bucket_id = 'creator-media');
create policy "creator_media_owner_write" on storage.objects
  for insert with check (bucket_id = 'creator-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "creator_media_owner_update" on storage.objects
  for update using (bucket_id = 'creator-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "creator_media_owner_delete" on storage.objects
  for delete using (bucket_id = 'creator-media' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "brand_logos_public_read" on storage.objects
  for select using (bucket_id = 'brand-logos');
create policy "brand_logos_owner_write" on storage.objects
  for insert with check (bucket_id = 'brand-logos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "brand_logos_owner_update" on storage.objects
  for update using (bucket_id = 'brand-logos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "brand_logos_owner_delete" on storage.objects
  for delete using (bucket_id = 'brand-logos' and (storage.foldername(name))[1] = auth.uid()::text);

-- ============================================================
-- Done. Next run seed.sql (optional demo data).
-- ============================================================
