/**
 * CUBE3 DEMO SEED SCRIPT
 * ----------------------------------------------------------------
 * Creates fictional demo creators, brands and an open campaign.
 * This uses the Supabase SERVICE ROLE key, so it must be run
 * from a trusted machine (Node.js), NEVER in the browser and
 * NEVER committed with a real key.
 *
 * Usage:
 *   1. npm install @supabase/supabase-js
 *   2. export SUPABASE_URL="https://xxxx.supabase.co"
 *      export SUPABASE_SERVICE_ROLE_KEY="xxxxx"   (Project Settings -> API)
 *   3. node seed.js
 *
 * All accounts created below are fictional demo data for a
 * fictional platform. They do not represent real people or brands.
 * Demo password for every seeded account: "Cube3Demo!123"
 * ----------------------------------------------------------------
 */

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars.');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});

const DEMO_PASSWORD = 'Cube3Demo!123';

const demoCreators = [
  {
    email: 'alex.morgan@demo.cube3.dev',
    full_name: 'Alex Morgan',
    handle: 'alexmorgan',
    category: 'Technology',
    description: '(Demo data) Tech reviewer covering gadgets, software and startups.',
    country: 'United States',
    verified: true,
    engagement_rate: 4.8,
    socials: [
      { platform: 'youtube', profile_url: 'https://youtube.com/@alexmorgan-demo', username: '@alexmorgan', follower_count: 820000 },
      { platform: 'instagram', profile_url: 'https://instagram.com/alexmorgan-demo', username: '@alexmorgan', follower_count: 410000 },
      { platform: 'x', profile_url: 'https://x.com/alexmorgan-demo', username: '@alexmorgan', follower_count: 150000 }
    ]
  },
  {
    email: 'ryan.tech@demo.cube3.dev',
    full_name: 'Ryan Tech',
    handle: 'ryantech',
    category: 'Technology',
    description: '(Demo data) Deep dives on AI, coding and consumer electronics.',
    country: 'Canada',
    verified: true,
    engagement_rate: 5.6,
    socials: [
      { platform: 'youtube', profile_url: 'https://youtube.com/@ryantech-demo', username: '@ryantech', follower_count: 610000 },
      { platform: 'tiktok', profile_url: 'https://tiktok.com/@ryantech-demo', username: '@ryantech', follower_count: 980000 }
    ]
  },
  {
    email: 'gameverse@demo.cube3.dev',
    full_name: 'GameVerse',
    handle: 'gameverse',
    category: 'Gaming',
    description: '(Demo data) Gaming channel with reviews, walkthroughs and esports coverage.',
    country: 'United Kingdom',
    verified: false,
    engagement_rate: 6.2,
    socials: [
      { platform: 'youtube', profile_url: 'https://youtube.com/@gameverse-demo', username: '@gameverse', follower_count: 1200000 },
      { platform: 'x', profile_url: 'https://x.com/gameverse-demo', username: '@gameverse', follower_count: 300000 }
    ]
  },
  {
    email: 'learnlab@demo.cube3.dev',
    full_name: 'Learn Lab',
    handle: 'learnlab',
    category: 'Education',
    description: '(Demo data) Bite-sized explainers on science, history and study tips.',
    country: 'Australia',
    verified: true,
    engagement_rate: 7.1,
    socials: [
      { platform: 'youtube', profile_url: 'https://youtube.com/@learnlab-demo', username: '@learnlab', follower_count: 340000 },
      { platform: 'instagram', profile_url: 'https://instagram.com/learnlab-demo', username: '@learnlab', follower_count: 190000 }
    ]
  },
  {
    email: 'future.finance@demo.cube3.dev',
    full_name: 'Future Finance',
    handle: 'futurefinance',
    category: 'Finance',
    description: '(Demo data) Personal finance and investing content for young professionals.',
    country: 'United States',
    verified: false,
    engagement_rate: 3.9,
    socials: [
      { platform: 'instagram', profile_url: 'https://instagram.com/futurefinance-demo', username: '@futurefinance', follower_count: 275000 },
      { platform: 'linkedin', profile_url: 'https://linkedin.com/company/futurefinance-demo', username: 'futurefinance', follower_count: 60000 }
    ]
  }
];

const demoBrands = [
  {
    email: 'hello@nova-audio-demo.cube3.dev',
    full_name: 'Nova Audio Team',
    company_name: 'Nova Audio',
    website: 'https://example.com/nova-audio-demo',
    description: '(Demo data) Wireless audio hardware startup.',
    industry: 'Consumer Electronics',
    country: 'United States'
  }
];

async function createUser(email, full_name, role) {
  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password: DEMO_PASSWORD,
    email_confirm: true,
    user_metadata: { full_name, role }
  });
  if (error) {
    if (error.message && error.message.includes('already been registered')) {
      const { data: list } = await supabase.auth.admin.listUsers();
      const existing = list.users.find(u => u.email === email);
      return existing;
    }
    throw error;
  }
  return data.user;
}

async function upsertProfile(userId, full_name, role) {
  const { error } = await supabase.from('profiles').upsert({
    id: userId, role, full_name, bio: 'Demo account for Cube3.'
  });
  if (error) throw error;
}

async function run() {
  console.log('Seeding demo creators...');
  for (const c of demoCreators) {
    const user = await createUser(c.email, c.full_name, 'creator');
    await upsertProfile(user.id, c.full_name, 'creator');

    const { data: creatorRow, error: creatorErr } = await supabase
      .from('creators')
      .upsert({
        profile_id: user.id,
        handle: c.handle,
        category: c.category,
        description: c.description,
        country: c.country,
        verified: c.verified,
        engagement_rate: c.engagement_rate
      }, { onConflict: 'profile_id' })
      .select()
      .single();
    if (creatorErr) throw creatorErr;

    for (const s of c.socials) {
      await supabase.from('social_accounts').upsert({
        creator_id: creatorRow.id,
        platform: s.platform,
        profile_url: s.profile_url,
        username: s.username,
        follower_count: s.follower_count
      }, { onConflict: 'creator_id,platform' });
    }
    console.log(`  + ${c.full_name}`);
  }

  console.log('Seeding demo brands...');
  let firstBrandId = null;
  for (const b of demoBrands) {
    const user = await createUser(b.email, b.full_name, 'brand');
    await upsertProfile(user.id, b.full_name, 'brand');

    const { data: brandRow, error: brandErr } = await supabase
      .from('brands')
      .upsert({
        profile_id: user.id,
        company_name: b.company_name,
        website: b.website,
        description: b.description,
        industry: b.industry,
        country: b.country
      }, { onConflict: 'profile_id' })
      .select()
      .single();
    if (brandErr) throw brandErr;
    firstBrandId = brandRow.id;
    console.log(`  + ${b.company_name}`);
  }

  if (firstBrandId) {
    console.log('Seeding demo campaign...');
    await supabase.from('campaigns').upsert({
      brand_id: firstBrandId,
      title: '(Demo) Wireless Earbuds Launch Collab',
      description: '(Demo data) Looking for tech creators to unbox and review our new wireless earbuds ahead of launch.',
      category: 'Technology',
      budget_min: 500,
      budget_max: 2500,
      currency: 'USD',
      platforms: ['youtube', 'instagram'],
      requirements: 'Minimum 50k followers, tech/gadget niche.',
      required_audience_size: 50000,
      preferred_country: 'United States',
      deliverables: '1 YouTube video + 2 Instagram stories',
      deadline: '2026-12-01',
      status: 'open'
    });
  }

  console.log('Done. Demo login password for all seeded accounts: ' + DEMO_PASSWORD);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
